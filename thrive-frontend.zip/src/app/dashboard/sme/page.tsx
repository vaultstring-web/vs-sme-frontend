'use client';

import React, { useState, ChangeEvent, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import apiClient from '@/lib/apiClient';
import {
  Box,
  Button,
  Typography,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Paper,
  Alert,
  CircularProgress,
  InputAdornment,
  Container,
  Snackbar,
  alpha
} from '@mui/material';
import {
  Save,
  ArrowLeft,
  ArrowRight,
  CheckCircle,
  User,
  Building2,
  DollarSign,
  Users,
  History,
  FileUp,
  Shield,
  ShieldCheck
} from 'lucide-react';
import { styled } from '@mui/material/styles';
import { useTheme } from '@/context/ThemeContext';
import { useApplications } from '@/hooks/useApplications';
import { useRouter } from 'next/navigation';
import LocalFilePreviewModal from '@/components/shared/LocalFilePreviewModal';
import DocumentViewer from '@/components/shared/DocumentViewer';
import { SmeFormData } from './types';

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

const businessTypes = ['Sole Proprietorship', 'Partnership', 'Private Limited Company', 'Cooperative', 'Other'];
const loanProducts = ['Working Capital Loan', 'Asset Financing', 'Invoice Financing', 'Trade Finance', 'Equipment Loan', 'Other'];
const repaymentMethods = ['Monthly', 'Quarterly', 'Bi-Annually', 'Bullet Payment', 'Custom Schedule'];

const steps = [
  { label: 'Business', icon: Building2 },
  { label: 'Loan Details', icon: DollarSign },
  { label: 'Group Lending', icon: Users },
  { label: 'Credit History', icon: History },
  { label: 'Documents', icon: FileUp },
  { label: 'Review', icon: Shield }
];

export default function SMELoanApplicationPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [activeStep, setActiveStep] = useState(0);
  const [isLoadingDraft, setIsLoadingDraft] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [showSnackbar, setShowSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [applicationId, setApplicationId] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ file: File; title: string } | null>(null);
  const [uploadedDocuments, setUploadedDocuments] = useState<Set<string>>(new Set());
  const [existingDocuments, setExistingDocuments] = useState<Record<string, { fileName: string; fileUrl: string }>>({});
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewerDocs, setViewerDocs] = useState<{ id?: string; name: string; fileUrl: string; documentType?: string }[]>([]);

  const {
    createDraftApplication,
    updateSMEApplication,
    uploadDocument,
    submitApplication,
    isLoading,
    error,
    clearError
  } = useApplications();

  const { theme } = useTheme();
  const isDarkMode = theme === 'dark';

  const [formData, setFormData] = useState<SmeFormData>({
    businessName: '',
    registrationNo: '',
    businessType: '',
    yearsInOperation: 0,
    loanProduct: '',
    loanAmount: 0,
    paybackPeriodMonths: 0,
    purposeOfLoan: '',
    repaymentMethod: '',
    estimatedMonthlyTurnover: 0,
    estimatedMonthlyProfit: 0,
    isGroupLending: false,
    groupName: '',
    groupMemberCount: 0,
    hasOutstandingLoans: false,
    outstandingLoanDetails: '',
    hasDefaulted: false,
    defaultExplanation: '',
    idDocument: null,
    businessRegistrationDoc: null,
    financialStatementDoc: null,
    agreeToTerms: false,
    consentToCreditCheck: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Load draft from URL parameter (takes precedence over localStorage)
  useEffect(() => {
    const draftId = searchParams?.get('id');
    const isNew = searchParams?.get('new');

    // If starting a new application, clear localStorage
    if (isNew === 'true') {
      localStorage.removeItem('smeLoanDraft');
      setApplicationId(null);
      setActiveStep(0);
      return;
    }

    if (draftId) {
      setIsLoadingDraft(true);
      const loadDraftFromBackend = async () => {
        try {
          const response = await apiClient.get(`/applications/${draftId}`);
          const application = response.data.app;

          // Verify it's a draft and SME type
          if (application.status !== 'DRAFT') {
            setSnackbarMessage('This application is not a draft and cannot be edited');
            setShowSnackbar(true);
            setTimeout(() => router.push('/dashboard/applications'), 2000);
            return;
          }

          if (application.type !== 'SME') {
            setSnackbarMessage('This is not an SME application');
            setShowSnackbar(true);
            setTimeout(() => router.push('/dashboard/applications'), 2000);
            return;
          }

          // Load the SME data into the form
          const smeData = application.smeData;
          if (smeData) {
            setFormData({
              businessName: smeData.businessName || '',
              registrationNo: smeData.registrationNo || '',
              businessType: smeData.businessType || '',
              yearsInOperation: smeData.yearsInOperation || 0,
              loanProduct: smeData.loanProduct || '',
              loanAmount: smeData.loanAmount || 0,
              paybackPeriodMonths: smeData.paybackPeriodMonths || 0,
              purposeOfLoan: smeData.purposeOfLoan || '',
              repaymentMethod: smeData.repaymentMethod || '',
              estimatedMonthlyTurnover: smeData.estimatedMonthlyTurnover || 0,
              estimatedMonthlyProfit: smeData.estimatedMonthlyProfit || 0,
              isGroupLending: !!(smeData.groupName || smeData.groupMemberCount),
              groupName: smeData.groupName || '',
              groupMemberCount: smeData.groupMemberCount || 0,
              hasOutstandingLoans: smeData.hasOutstandingLoans || false,
              outstandingLoanDetails: smeData.outstandingLoanDetails || '',
              hasDefaulted: smeData.hasDefaulted || false,
              defaultExplanation: smeData.defaultExplanation || '',
              idDocument: null,
              businessRegistrationDoc: null,
              financialStatementDoc: null,
              agreeToTerms: false,
              consentToCreditCheck: false,
            });
          }

          setApplicationId(draftId);

          // Mark documents as uploaded if they exist in the backend
          if (application.documents && application.documents.length > 0) {
            const uploadedDocs = new Set<string>();
            const existingDocs: Record<string, { fileName: string; fileUrl: string }> = {};
            application.documents.forEach((doc: any) => {
              uploadedDocs.add(doc.documentType);
              existingDocs[doc.documentType] = { fileName: doc.fileName, fileUrl: doc.fileUrl };
            });
            setUploadedDocuments(uploadedDocs);
            setExistingDocuments(existingDocs);
          }

          setSnackbarMessage('Draft loaded successfully');
          setShowSnackbar(true);
        } catch (error) {
          console.error('Error loading draft:', error);
          setSnackbarMessage('Failed to load draft application');
          setShowSnackbar(true);
        } finally {
          setIsLoadingDraft(false);
        }
      };

      loadDraftFromBackend();
    } else {
      // Load draft from localStorage only if no URL parameter
      const savedDraft = localStorage.getItem('smeLoanDraft');
      if (savedDraft) {
        try {
          const draft = JSON.parse(savedDraft);
          setFormData(draft.formData || draft);
          if (draft.step !== undefined) setActiveStep(draft.step);
          if (draft.applicationId) setApplicationId(draft.applicationId);
        } catch (error) {
          console.error('Failed to load draft:', error);
        }
      }
    }
  }, [searchParams, router]);

  // Show error from context
  useEffect(() => {
    if (error) {
      setSnackbarMessage(error);
      setShowSnackbar(true);
      clearError();
    }
  }, [error, clearError]);

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {};

    switch (step) {
      case 0: // Business
        if (!formData.businessName.trim()) newErrors.businessName = 'Business name is required';
        if (!formData.businessType) newErrors.businessType = 'Business type is required';
        if (!formData.yearsInOperation || formData.yearsInOperation <= 0)
          newErrors.yearsInOperation = 'Years in operation is required';
        break;
      case 1: // Loan Details
        if (!formData.loanProduct) newErrors.loanProduct = 'Loan product is required';
        if (!formData.loanAmount || formData.loanAmount <= 0) newErrors.loanAmount = 'Loan amount is required';
        else if (formData.loanAmount < 100000 || formData.loanAmount > 5000000)
          newErrors.loanAmount = 'Loan amount must be between MK100,000 and MK5,000,000';
        if (!formData.paybackPeriodMonths || formData.paybackPeriodMonths <= 0)
          newErrors.paybackPeriodMonths = 'Payback period is required';
        else if (formData.paybackPeriodMonths < 1 || formData.paybackPeriodMonths > 120)
          newErrors.paybackPeriodMonths = 'Payback period must be 1-120 months';
        if (!formData.purposeOfLoan.trim()) newErrors.purposeOfLoan = 'Purpose of loan is required';
        if (!formData.repaymentMethod) newErrors.repaymentMethod = 'Repayment method is required';
        break;
      case 2: // Group Lending
        if (formData.isGroupLending) {
          if (!formData.groupName.trim()) newErrors.groupName = 'Group name is required';
          if (!formData.groupMemberCount || formData.groupMemberCount <= 0)
            newErrors.groupMemberCount = 'Number of members is required';
          else if (formData.groupMemberCount < 2 || formData.groupMemberCount > 20)
            newErrors.groupMemberCount = 'Group must have 2-20 members';
        }
        break;
      case 3: // Credit History
        if (formData.hasOutstandingLoans && !formData.outstandingLoanDetails.trim())
          newErrors.outstandingLoanDetails = 'Please provide details of outstanding loans';
        if (formData.hasDefaulted && !formData.defaultExplanation.trim())
          newErrors.defaultExplanation = 'Please explain the default';
        break;
      case 4: // Documents
        if (!formData.idDocument && !existingDocuments['ID_DOCUMENT']) {
          newErrors.idDocument = 'ID document is required';
        }
        if (!formData.businessRegistrationDoc && !existingDocuments['BUSINESS_REGISTRATION']) {
          newErrors.businessRegistrationDoc = 'Business registration document is required';
        }
        break;
      case 5: // Review
        if (!formData.agreeToTerms) newErrors.agreeToTerms = 'You must agree to the terms and conditions';
        if (!formData.consentToCreditCheck)
          newErrors.consentToCreditCheck = 'You must consent to credit check';
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement> | { target: { name: string; value: any } }) => {
    const { name, value } = e.target as { name: string; value: any };
    const inputElement = e.target as HTMLInputElement;
    const parsedValue = inputElement.type === 'number' ? parseFloat(value) || 0 : value;

    setFormData(prev => ({
      ...prev,
      [name]: parsedValue
    }));

    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleFileUpload = (name: string) => (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({
      ...prev,
      [name]: file
    }));

    // Clear the "uploaded" status if a new file is selected
    const typeMap: Record<string, string> = {
      idDocument: 'ID_DOCUMENT',
      businessRegistrationDoc: 'BUSINESS_REGISTRATION',
      financialStatementDoc: 'FINANCIAL_STATEMENT'
    };

    const docType = typeMap[name];
    if (docType && file) {
      setUploadedDocuments(prev => {
        const next = new Set(prev);
        next.delete(docType);
        return next;
      });
      setExistingDocuments(prev => {
        const next = { ...prev };
        delete next[docType];
        return next;
      });
    }

    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleSelectChange = (name: string) => (e: { target: { value: any } }) => {
    setFormData(prev => ({
      ...prev,
      [name]: e.target.value
    }));

    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const openPreview = (file: File, title: string) => {
    setPreview({ file, title });
  };

  const openExistingPreview = (type: string) => {
    const doc = existingDocuments[type];
    if (doc) {
      setViewerDocs([{ name: doc.fileName, fileUrl: doc.fileUrl, documentType: type }]);
      setIsViewerOpen(true);
    }
  };

  const handleSaveDraft = async (): Promise<string | null> => {
    try {
      // Prepare data for backend - filter out empty/undefined values
      const backendData: Record<string, any> = {
        businessName: formData.businessName?.trim() || null,
        registrationNo: formData.registrationNo?.trim() || null,
        businessType: formData.businessType || null,
        yearsInOperation: formData.yearsInOperation || null,
        loanProduct: formData.loanProduct || null,
        loanAmount: formData.loanAmount || null,
        paybackPeriodMonths: formData.paybackPeriodMonths || null,
        purposeOfLoan: formData.purposeOfLoan?.trim() || null,
        repaymentMethod: formData.repaymentMethod || null,
        estimatedMonthlyTurnover: formData.estimatedMonthlyTurnover || null,
        estimatedMonthlyProfit: formData.estimatedMonthlyProfit || null,
        hasOutstandingLoans: formData.hasOutstandingLoans,
        hasDefaulted: formData.hasDefaulted,
      };

      // Conditionally include group/loan details
      if (formData.isGroupLending) {
        backendData.groupName = formData.groupName?.trim() || null;
        backendData.groupMemberCount = formData.groupMemberCount || null;
      } else {
        backendData.groupName = null;
        backendData.groupMemberCount = null;
      }

      if (formData.hasOutstandingLoans) {
        backendData.outstandingLoanDetails = formData.outstandingLoanDetails?.trim() || null;
      } else {
        backendData.outstandingLoanDetails = null;
      }

      if (formData.hasDefaulted) {
        backendData.defaultExplanation = formData.defaultExplanation?.trim() || null;
      } else {
        backendData.defaultExplanation = null;
      }

      // Remove undefined values
      Object.keys(backendData).forEach(key => {
        if (backendData[key] === undefined) delete backendData[key];
      });

      let id = applicationId;

      if (!id) {
        // Step 1: Create an empty draft (no validation)
        const result = await createDraftApplication('SME');
        id = result.id;
        setApplicationId(id);
      }

      // Step 2: Update the draft with the actual data (unvalidated)
      await updateSMEApplication(id, backendData);

      // Step 3: Upload documents if any are present (only upload new ones)
      try {
        const uploadTasks = [];

        if (formData.idDocument && !uploadedDocuments.has('ID_DOCUMENT')) {
          uploadTasks.push(
            uploadDocument(id, formData.idDocument, 'ID_DOCUMENT')
              .then(() => {
                setUploadedDocuments(prev => new Set(prev).add('ID_DOCUMENT'));
              })
          );
        }

        if (formData.businessRegistrationDoc && !uploadedDocuments.has('BUSINESS_REGISTRATION')) {
          uploadTasks.push(
            uploadDocument(id, formData.businessRegistrationDoc, 'BUSINESS_REGISTRATION')
              .then(() => {
                setUploadedDocuments(prev => new Set(prev).add('BUSINESS_REGISTRATION'));
              })
          );
        }

        if (formData.financialStatementDoc && !uploadedDocuments.has('FINANCIAL_STATEMENT')) {
          uploadTasks.push(
            uploadDocument(id, formData.financialStatementDoc, 'FINANCIAL_STATEMENT')
              .then(() => {
                setUploadedDocuments(prev => new Set(prev).add('FINANCIAL_STATEMENT'));
              })
          );
        }

        if (uploadTasks.length > 0) {
          await Promise.all(uploadTasks);
        }
      } catch (docError) {
        console.error('Document upload error during draft save:', docError);
        // Continue even if document upload fails
      }

      // Save metadata to localStorage
      const draftMetadata = {
        formData: {
          ...formData,
          idDocument: formData.idDocument ? {
            name: formData.idDocument.name,
            type: formData.idDocument.type,
            size: formData.idDocument.size,
            lastModified: formData.idDocument.lastModified,
          } : null,
          businessRegistrationDoc: formData.businessRegistrationDoc ? {
            name: formData.businessRegistrationDoc.name,
            type: formData.businessRegistrationDoc.type,
            size: formData.businessRegistrationDoc.size,
            lastModified: formData.businessRegistrationDoc.lastModified,
          } : null,
          financialStatementDoc: formData.financialStatementDoc ? {
            name: formData.financialStatementDoc.name,
            type: formData.financialStatementDoc.type,
            size: formData.financialStatementDoc.size,
            lastModified: formData.financialStatementDoc.lastModified,
          } : null,
        },
        applicationId: id,
        savedAt: new Date().toISOString(),
        step: activeStep,
      };

      localStorage.setItem('smeLoanDraft', JSON.stringify(draftMetadata));

      setSnackbarMessage('Draft saved successfully!');
      setShowSnackbar(true);

      return id;
    } catch (error: any) {
      console.error('Save draft error:', error);
      setSnackbarMessage(error.message || 'Failed to save draft');
      setShowSnackbar(true);
      return null;
    }
  };

  const uploadDocuments = async (appId: string): Promise<boolean> => {
    try {
      const uploadTasks = [];

      if (formData.idDocument) {
        uploadTasks.push(
          uploadDocument(appId, formData.idDocument, 'ID_DOCUMENT')
        );
      }

      if (formData.businessRegistrationDoc) {
        uploadTasks.push(
          uploadDocument(appId, formData.businessRegistrationDoc, 'BUSINESS_REGISTRATION')
        );
      }

      if (formData.financialStatementDoc) {
        uploadTasks.push(
          uploadDocument(appId, formData.financialStatementDoc, 'FINANCIAL_STATEMENT')
        );
      }

      await Promise.all(uploadTasks);
      return true;
    } catch (error) {
      console.error('Document upload error:', error);
      throw new Error('Failed to upload documents');
    }
  };

  const handleSubmit = async () => {
    if (!validateStep(5)) return;

    setIsSubmitting(true);

    try {
      // First ensure we have an application ID by saving the draft
      let id = applicationId;
      if (!id) {
        id = await handleSaveDraft(); // Get ID directly from the function

        if (!id) {
          throw new Error('Failed to create application');
        }
      }

      // Upload all required documents
      await uploadDocuments(id);

      // Submit the application
      await submitApplication(id);

      // Clear local storage
      localStorage.removeItem('smeLoanDraft');

      setSubmitSuccess(true);
      setSnackbarMessage('Application submitted successfully!');
      setShowSnackbar(true);

      // Redirect to applications page after a brief delay
      setTimeout(() => {
        router.push('/dashboard/applications');
      }, 2000);

    } catch (error: any) {
      console.error('Submission error:', error);
      // Error will be shown via the error state from context
    } finally {
      setIsSubmitting(false);
    }
  };

  const progress = Math.round(((activeStep + 1) / steps.length) * 100);

  const limeColors = {
    50: '#f7fee7',
    100: '#ecfccb',
    200: '#d9f99d',
    300: '#bef264',
    400: '#a3e635',
    500: '#84cc16',
    600: '#65a30d',
    700: '#4d7c0f',
    800: '#3f6212',
    900: '#365314',
  };

  const baseTextFieldProps = {
    fullWidth: true,
    variant: 'outlined' as const,
    sx: {
      '& .MuiOutlinedInput-root': {
        bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.02)' : 'rgba(255, 255, 255, 0.9)',
        backdropFilter: 'blur(10px)',
        borderRadius: '12px',
        '& fieldset': {
          borderColor: isDarkMode ? 'rgba(132, 204, 22, 0.2)' : 'rgba(132, 204, 22, 0.15)',
          borderWidth: '1.5px',
        },
        '&:hover fieldset': {
          borderColor: isDarkMode ? 'rgba(132, 204, 22, 0.4)' : 'rgba(132, 204, 22, 0.3)',
        },
        '&.Mui-focused fieldset': {
          borderColor: limeColors[500],
          borderWidth: '2px',
        },
      },
      '& .MuiInputLabel-root': {
        color: isDarkMode ? '#a1a1aa' : '#71717a',
        fontWeight: 500,
      },
      '& .MuiInputLabel-root.Mui-focused': {
        color: limeColors[500],
      },
      '& .MuiInputBase-input': {
        color: isDarkMode ? '#ffffff' : 'inherit',
      },
      '& .MuiInputBase-input::placeholder': {
        color: isDarkMode ? 'rgba(255, 255, 255, 0.5)' : 'inherit',
      },
      '& .MuiInputAdornment-root': {
        color: isDarkMode ? '#ffffff' : 'inherit',
      },
      '& .MuiInputAdornment-root p': {
        color: isDarkMode ? '#ffffff' : 'inherit',
      },
    }
  };

  const baseSelectProps = {
    sx: {
      '& .MuiSelect-select': {
        bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.02)' : 'rgba(255, 255, 255, 0.9)',
        backdropFilter: 'blur(10px)',
        borderRadius: '12px',
        color: isDarkMode ? '#ffffff' : 'inherit',
      },
      '& .MuiOutlinedInput-root': {
        borderRadius: '12px',
        '& fieldset': {
          borderColor: isDarkMode ? 'rgba(132, 204, 22, 0.2)' : 'rgba(132, 204, 22, 0.15)',
          borderWidth: '1.5px',
        },
        '&:hover fieldset': {
          borderColor: isDarkMode ? 'rgba(132, 204, 22, 0.4)' : 'rgba(132, 204, 22, 0.3)',
        },
        '&.Mui-focused fieldset': {
          borderColor: limeColors[500],
          borderWidth: '2px',
        },
      },
      '& .MuiInputLabel-root': {
        color: isDarkMode ? '#a1a1aa' : '#71717a',
        fontWeight: 500,
      },
      '& .MuiInputLabel-root.Mui-focused': {
        color: limeColors[500],
      },
      '& .MuiSelect-select.MuiSelect-outlined': {
        color: isDarkMode ? '#ffffff' : 'inherit',
      },
      '& .MuiFormHelperText-root': {
        color: isDarkMode ? '#a1a1aa' : '#71717a',
      },
    }
  };

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Box>
            <Typography variant="h5" sx={{ mb: 3, fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>
              Business Information
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              <TextField
                {...baseTextFieldProps}
                label="Business Name"
                name="businessName"
                value={formData.businessName}
                onChange={handleInputChange}
                error={!!errors.businessName}
                helperText={errors.businessName}
                required
              />
              <TextField
                {...baseTextFieldProps}
                label="Business Registration Number"
                name="registrationNo"
                value={formData.registrationNo}
                onChange={handleInputChange}
                helperText="Optional if not registered"
              />
              <FormControl fullWidth error={!!errors.businessType} {...baseSelectProps}>
                <InputLabel>Business Type</InputLabel>
                <Select
                  name="businessType"
                  value={formData.businessType}
                  onChange={handleSelectChange('businessType')}
                  label="Business Type"
                  required
                >
                  {businessTypes.map((type) => (
                    <MenuItem key={type} value={type}>{type}</MenuItem>
                  ))}
                </Select>
                {errors.businessType && (
                  <Typography variant="caption" color="error" sx={{ mt: 0.5 }}>
                    {errors.businessType}
                  </Typography>
                )}
              </FormControl>
              <TextField
                {...baseTextFieldProps}
                type="number"
                label="Years in Operation"
                name="yearsInOperation"
                value={formData.yearsInOperation || ''}
                onChange={handleInputChange}
                error={!!errors.yearsInOperation}
                helperText={errors.yearsInOperation}
                required
                inputProps={{ min: 0, step: 1 }}
              />
            </Box>
          </Box>
        );

      case 1: {
        // SME Loan Calculation — 6% p.a. reducing balance
        const loanAmount = formData.loanAmount || 0;
        const processingFee = loanAmount * 0.05;        // 5% one-time
        const insuranceFee = loanAmount * 0.012;         // 1.2% one-time
        const totalDeductions = processingFee + insuranceFee;
        const amountReceived = loanAmount - totalDeductions;

        const monthlyRate = 0.06 / 12; // 6% p.a. → 0.5% per month
        const months = formData.paybackPeriodMonths || 1;
        const monthlyPayment = months > 0 && loanAmount > 0
          ? loanAmount * monthlyRate / (1 - Math.pow(1 + monthlyRate, -months))
          : 0;
        const totalRepayment = monthlyPayment * months;
        const totalInterest = totalRepayment - loanAmount;

        return (
          <Box>
            <Typography variant="h5" sx={{ mb: 3, fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>
              Loan Details
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              <FormControl fullWidth error={!!errors.loanProduct} {...baseSelectProps}>
                <InputLabel>Loan Product</InputLabel>
                <Select
                  name="loanProduct"
                  value={formData.loanProduct}
                  onChange={handleSelectChange('loanProduct')}
                  label="Loan Product"
                  required
                >
                  {loanProducts.map((product) => (
                    <MenuItem key={product} value={product}>{product}</MenuItem>
                  ))}
                </Select>
                {errors.loanProduct && (
                  <Typography variant="caption" color="error" sx={{ mt: 0.5 }}>
                    {errors.loanProduct}
                  </Typography>
                )}
              </FormControl>

              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 3 }}>
                <TextField
                  {...baseTextFieldProps}
                  type="number"
                  label="Loan Amount"
                  name="loanAmount"
                  value={formData.loanAmount || ''}
                  onChange={handleInputChange}
                  error={!!errors.loanAmount}
                  helperText={errors.loanAmount || 'Amount between MK100,000 and MK5,000,000'}
                  required
                  InputProps={{
                    startAdornment: <InputAdornment position="start">MK</InputAdornment>,
                  }}
                />
                <TextField
                  {...baseTextFieldProps}
                  type="number"
                  label="Payback Period (Months)"
                  name="paybackPeriodMonths"
                  value={formData.paybackPeriodMonths || ''}
                  onChange={handleInputChange}
                  error={!!errors.paybackPeriodMonths}
                  helperText={errors.paybackPeriodMonths || '1-120 months'}
                  required
                  inputProps={{ min: 1, max: 120, step: 1 }}
                />
              </Box>

              {/* Loan Breakdown — only shown when both fields are filled */}
              {loanAmount > 0 && formData.paybackPeriodMonths > 0 && (
                <Box sx={{
                  p: 3,
                  borderRadius: '16px',
                  bgcolor: alpha(limeColors[500], 0.05),
                  border: `1.5px solid ${alpha(limeColors[500], 0.2)}`,
                }}>
                  <Typography variant="h6" sx={{ color: isDarkMode ? 'white' : '#18181b', fontWeight: 600, mb: 3 }}>
                    Loan Breakdown
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>

                    {/* Loan Amount */}
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Loan Amount:</Typography>
                      <Typography sx={{ color: isDarkMode ? 'white' : '#18181b', fontWeight: 600 }}>
                        MK {loanAmount.toLocaleString()}
                      </Typography>
                    </Box>

                    {/* Processing Fee */}
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
                        Processing Fee (5% one-time):
                      </Typography>
                      <Typography sx={{ color: '#ef4444', fontWeight: 600 }}>
                        - MK {processingFee.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </Typography>
                    </Box>

                    {/* Insurance */}
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
                        Insurance (1.2% one-time):
                      </Typography>
                      <Typography sx={{ color: '#ef4444', fontWeight: 600 }}>
                        - MK {insuranceFee.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </Typography>
                    </Box>

                    {/* Total Deductions */}
                    <Box sx={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      pt: 1, borderTop: `1px dashed ${isDarkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}`
                    }}>
                      <Typography sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a', fontWeight: 600 }}>
                        Total Deductions:
                      </Typography>
                      <Typography sx={{ color: '#ef4444', fontWeight: 700 }}>
                        - MK {totalDeductions.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </Typography>
                    </Box>

                    {/* Amount Received */}
                    <Box sx={{
                      p: 2, borderRadius: '12px',
                      bgcolor: alpha(limeColors[500], 0.1),
                      border: `1px solid ${limeColors[500]}`,
                    }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Typography sx={{ color: limeColors[500], fontWeight: 700 }}>
                          Amount You'll Receive:
                        </Typography>
                        <Typography variant="h5" sx={{ color: limeColors[500], fontWeight: 800 }}>
                          MK {amountReceived.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </Typography>
                      </Box>
                      <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a', display: 'block', mt: 0.5 }}>
                        After one-time deductions (5% processing + 1.2% insurance)
                      </Typography>
                    </Box>

                    {/* Repayment Breakdown */}
                    <Box sx={{ p: 2, borderRadius: '12px', bgcolor: alpha(limeColors[500], 0.05), mt: 1 }}>
                      <Typography variant="subtitle2" sx={{ color: limeColors[500], fontWeight: 600, mb: 2 }}>
                        Repayment Breakdown (6% p.a. – Reducing Balance)
                      </Typography>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                        <Typography sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Principal:</Typography>
                        <Typography sx={{ color: isDarkMode ? 'white' : '#18181b' }}>
                          MK {loanAmount.toLocaleString()}
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                        <Typography sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
                          Total Interest (reducing balance):
                        </Typography>
                        <Typography sx={{ color: isDarkMode ? 'white' : '#18181b' }}>
                          MK {totalInterest.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </Typography>
                      </Box>
                      <Box sx={{
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                        pt: 1, borderTop: `1px solid ${isDarkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}`
                      }}>
                        <Typography sx={{ color: isDarkMode ? 'white' : '#18181b', fontWeight: 600 }}>
                          Total Repayment (Principal + Interest):
                        </Typography>
                        <Typography sx={{ color: limeColors[500], fontWeight: 700 }}>
                          MK {totalRepayment.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </Typography>
                      </Box>
                    </Box>

                    {/* Monthly Payment highlight */}
                    <Box sx={{
                      p: 3, borderRadius: '12px', mt: 1,
                      bgcolor: alpha(limeColors[500], 0.1),
                      border: `2px solid ${limeColors[500]}`,
                      textAlign: 'center',
                    }}>
                      <Typography variant="body2" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a', mb: 1 }}>
                        Monthly Repayment Amount
                      </Typography>
                      <Typography variant="h3" sx={{ color: limeColors[500], fontWeight: 800, mb: 1 }}>
                        MK {monthlyPayment.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </Typography>
                      <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
                        Equal monthly instalments – reducing balance over {formData.paybackPeriodMonths} months
                      </Typography>
                      <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a', display: 'block', mt: 1 }}>
                        Total interest paid: MK {totalInterest.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </Typography>
                    </Box>

                  </Box>
                </Box>
              )}

              <TextField
                {...baseTextFieldProps}
                label="Purpose of Loan"
                name="purposeOfLoan"
                value={formData.purposeOfLoan}
                onChange={handleInputChange}
                error={!!errors.purposeOfLoan}
                helperText={errors.purposeOfLoan}
                required
                multiline
                rows={3}
              />
              <FormControl fullWidth error={!!errors.repaymentMethod} {...baseSelectProps}>
                <InputLabel>Repayment Method</InputLabel>
                <Select
                  name="repaymentMethod"
                  value={formData.repaymentMethod}
                  onChange={handleSelectChange('repaymentMethod')}
                  label="Repayment Method"
                  required
                >
                  {repaymentMethods.map((method) => (
                    <MenuItem key={method} value={method}>{method}</MenuItem>
                  ))}
                </Select>
                {errors.repaymentMethod && (
                  <Typography variant="caption" color="error" sx={{ mt: 0.5 }}>
                    {errors.repaymentMethod}
                  </Typography>
                )}
              </FormControl>
              <TextField
                {...baseTextFieldProps}
                type="number"
                label="Estimated Monthly Turnover"
                name="estimatedMonthlyTurnover"
                value={formData.estimatedMonthlyTurnover || ''}
                onChange={handleInputChange}
                helperText="Optional"
                InputProps={{
                  startAdornment: <InputAdornment position="start">MK</InputAdornment>,
                }}
              />
              <TextField
                {...baseTextFieldProps}
                type="number"
                label="Estimated Monthly Profit"
                name="estimatedMonthlyProfit"
                value={formData.estimatedMonthlyProfit || ''}
                onChange={handleInputChange}
                helperText="Optional"
                InputProps={{
                  startAdornment: <InputAdornment position="start">MK</InputAdornment>,
                }}
              />
            </Box>
          </Box>
        );
      }

      case 2:
        return (
          <Box>
            <Typography variant="h5" sx={{ mb: 3, fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>
              Group Lending (Optional)
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.isGroupLending}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, isGroupLending: e.target.checked }));
                      if (!e.target.checked) {
                        setFormData(prev => ({ ...prev, groupName: '', groupMemberCount: 0 }));
                      }
                    }}
                    sx={{
                      color: limeColors[500],
                      '&.Mui-checked': {
                        color: limeColors[500],
                      },
                    }}
                  />
                }
                label="Apply as part of a group"
              />
              {formData.isGroupLending && (
                <>
                  <TextField
                    {...baseTextFieldProps}
                    label="Group Name"
                    name="groupName"
                    value={formData.groupName}
                    onChange={handleInputChange}
                    error={!!errors.groupName}
                    helperText={errors.groupName}
                    required={formData.isGroupLending}
                  />
                  <TextField
                    {...baseTextFieldProps}
                    type="number"
                    label="Number of Group Members"
                    name="groupMemberCount"
                    value={formData.groupMemberCount || ''}
                    onChange={handleInputChange}
                    error={!!errors.groupMemberCount}
                    helperText={errors.groupMemberCount || '2-20 members'}
                    required={formData.isGroupLending}
                    inputProps={{ min: 2, max: 20, step: 1 }}
                  />
                </>
              )}
            </Box>
          </Box>
        );

      case 3:
        return (
          <Box>
            <Typography variant="h5" sx={{ mb: 3, fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>
              Credit History
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.hasOutstandingLoans}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, hasOutstandingLoans: e.target.checked }));
                      if (!e.target.checked) {
                        setFormData(prev => ({ ...prev, outstandingLoanDetails: '' }));
                      }
                    }}
                    sx={{
                      color: limeColors[500],
                      '&.Mui-checked': {
                        color: limeColors[500],
                      },
                    }}
                  />
                }
                label="I have outstanding loans"
              />
              {formData.hasOutstandingLoans && (
                <TextField
                  {...baseTextFieldProps}
                  label="Outstanding Loan Details"
                  name="outstandingLoanDetails"
                  value={formData.outstandingLoanDetails}
                  onChange={handleInputChange}
                  error={!!errors.outstandingLoanDetails}
                  helperText={errors.outstandingLoanDetails || 'Provide lender, amount, and repayment status'}
                  required={formData.hasOutstandingLoans}
                  multiline
                  rows={3}
                />
              )}

              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.hasDefaulted}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, hasDefaulted: e.target.checked }));
                      if (!e.target.checked) {
                        setFormData(prev => ({ ...prev, defaultExplanation: '' }));
                      }
                    }}
                    sx={{
                      color: limeColors[500],
                      '&.Mui-checked': {
                        color: limeColors[500],
                      },
                    }}
                  />
                }
                label="I have previously defaulted on a loan"
              />
              {formData.hasDefaulted && (
                <TextField
                  {...baseTextFieldProps}
                  label="Default Explanation"
                  name="defaultExplanation"
                  value={formData.defaultExplanation}
                  onChange={handleInputChange}
                  error={!!errors.defaultExplanation}
                  helperText={errors.defaultExplanation || 'Explain the circumstances'}
                  required={formData.hasDefaulted}
                  multiline
                  rows={3}
                />
              )}
            </Box>
          </Box>
        );

      case 4:
        return (
          <Box>
            <Typography variant="h5" sx={{ mb: 3, fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>
              Required Documents
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              {/* ID Document */}
              <Box>
                <Typography variant="body2" sx={{ mb: 1, fontWeight: 600, color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
                  ID Document (Required) *
                </Typography>
                <Button
                  component="label"
                  variant="outlined"
                  startIcon={<FileUp size={18} />}
                  sx={{
                    borderColor: errors.idDocument ? 'error.main' : (isDarkMode ? 'rgba(132, 204, 22, 0.3)' : 'rgba(132, 204, 22, 0.2)'),
                    color: isDarkMode ? 'white' : '#18181b',
                    borderRadius: '12px',
                    textTransform: 'none',
                    py: 1.5,
                    px: 3,
                    width: '100%',
                    justifyContent: 'flex-start',
                  }}
                >
                  {formData.idDocument ? formData.idDocument.name :
                    existingDocuments['ID_DOCUMENT'] ? `Already uploaded: ${existingDocuments['ID_DOCUMENT'].fileName}` :
                      'Choose ID Document'}
                  <VisuallyHiddenInput type="file" onChange={handleFileUpload('idDocument')} accept=".pdf,.jpg,.jpeg,.png" />
                </Button>
                <Box sx={{ mt: 1, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                  {formData.idDocument && (
                    <Button
                      size="small"
                      variant="text"
                      onClick={() => openPreview(formData.idDocument as File, 'ID Document')}
                      sx={{ textTransform: 'none', color: isDarkMode ? '#a3e635' : '#65a30d' }}
                    >
                      Preview Selected
                    </Button>
                  )}
                  {existingDocuments['ID_DOCUMENT'] && (
                    <Button
                      size="small"
                      variant="text"
                      onClick={() => openExistingPreview('ID_DOCUMENT')}
                      sx={{ textTransform: 'none', color: isDarkMode ? '#a3e635' : '#65a30d' }}
                    >
                      View Current
                    </Button>
                  )}
                </Box>
                {errors.idDocument && (
                  <Typography variant="caption" color="error" sx={{ mt: 0.5, display: 'block' }}>
                    {errors.idDocument}
                  </Typography>
                )}
              </Box>

              {/* Business Registration */}
              <Box>
                <Typography variant="body2" sx={{ mb: 1, fontWeight: 600, color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
                  Business Registration Document (Required) *
                </Typography>
                <Button
                  component="label"
                  variant="outlined"
                  startIcon={<FileUp size={18} />}
                  sx={{
                    borderColor: errors.businessRegistrationDoc ? 'error.main' : (isDarkMode ? 'rgba(132, 204, 22, 0.3)' : 'rgba(132, 204, 22, 0.2)'),
                    color: isDarkMode ? 'white' : '#18181b',
                    borderRadius: '12px',
                    textTransform: 'none',
                    py: 1.5,
                    px: 3,
                    width: '100%',
                    justifyContent: 'flex-start',
                  }}
                >
                  {formData.businessRegistrationDoc ? formData.businessRegistrationDoc.name :
                    existingDocuments['BUSINESS_REGISTRATION'] ? `Already uploaded: ${existingDocuments['BUSINESS_REGISTRATION'].fileName}` :
                      'Choose Business Registration'}
                  <VisuallyHiddenInput type="file" onChange={handleFileUpload('businessRegistrationDoc')} accept=".pdf,.jpg,.jpeg,.png" />
                </Button>
                <Box sx={{ mt: 1, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                  {formData.businessRegistrationDoc && (
                    <Button
                      size="small"
                      variant="text"
                      onClick={() => openPreview(formData.businessRegistrationDoc as File, 'Business Registration Document')}
                      sx={{ textTransform: 'none', color: isDarkMode ? '#a3e635' : '#65a30d' }}
                    >
                      Preview Selected
                    </Button>
                  )}
                  {existingDocuments['BUSINESS_REGISTRATION'] && (
                    <Button
                      size="small"
                      variant="text"
                      onClick={() => openExistingPreview('BUSINESS_REGISTRATION')}
                      sx={{ textTransform: 'none', color: isDarkMode ? '#a3e635' : '#65a30d' }}
                    >
                      View Current
                    </Button>
                  )}
                </Box>
                {errors.businessRegistrationDoc && (
                  <Typography variant="caption" color="error" sx={{ mt: 0.5, display: 'block' }}>
                    {errors.businessRegistrationDoc}
                  </Typography>
                )}
              </Box>

              {/* Financial Statement */}
              <Box>
                <Typography variant="body2" sx={{ mb: 1, fontWeight: 600, color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
                  Financial Statement (Optional)
                </Typography>
                <Button
                  component="label"
                  variant="outlined"
                  startIcon={<FileUp size={18} />}
                  sx={{
                    borderColor: isDarkMode ? 'rgba(132, 204, 22, 0.3)' : 'rgba(132, 204, 22, 0.2)',
                    color: isDarkMode ? 'white' : '#18181b',
                    borderRadius: '12px',
                    textTransform: 'none',
                    py: 1.5,
                    px: 3,
                    width: '100%',
                    justifyContent: 'flex-start',
                  }}
                >
                  {formData.financialStatementDoc ? formData.financialStatementDoc.name :
                    existingDocuments['FINANCIAL_STATEMENT'] ? `Already uploaded: ${existingDocuments['FINANCIAL_STATEMENT'].fileName}` :
                      'Choose Financial Statement'}
                  <VisuallyHiddenInput type="file" onChange={handleFileUpload('financialStatementDoc')} accept=".pdf,.jpg,.jpeg,.png" />
                </Button>
                <Box sx={{ mt: 1, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                  {formData.financialStatementDoc && (
                    <Button
                      size="small"
                      variant="text"
                      onClick={() => openPreview(formData.financialStatementDoc as File, 'Financial Statement')}
                      sx={{ textTransform: 'none', color: isDarkMode ? '#a3e635' : '#65a30d' }}
                    >
                      Preview Selected
                    </Button>
                  )}
                  {existingDocuments['FINANCIAL_STATEMENT'] && (
                    <Button
                      size="small"
                      variant="text"
                      onClick={() => openExistingPreview('FINANCIAL_STATEMENT')}
                      sx={{ textTransform: 'none', color: isDarkMode ? '#a3e635' : '#65a30d' }}
                    >
                      View Current
                    </Button>
                  )}
                </Box>
              </Box>
            </Box>
          </Box>
        );

      case 5:
        return (
          <Box>
            <Typography variant="h5" sx={{ mb: 3, fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>
              Review & Submit
            </Typography>

            {/* Summary */}
            <Paper
              elevation={0}
              sx={{
                p: 3,
                mb: 3,
                bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.02)' : 'rgba(0, 0, 0, 0.02)',
                borderRadius: '12px',
                border: `1.5px solid ${isDarkMode ? 'rgba(132, 204, 22, 0.2)' : 'rgba(132, 204, 22, 0.15)'}`
              }}
            >
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 600, color: isDarkMode ? 'white' : '#18181b' }}>
                Application Summary
              </Typography>

              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
                <Box>
                  <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Business Name</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: isDarkMode ? 'white' : '#18181b' }}>{formData.businessName}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Business Type</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: isDarkMode ? 'white' : '#18181b' }}>{formData.businessType}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Loan Product</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: isDarkMode ? 'white' : '#18181b' }}>{formData.loanProduct}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Loan Amount</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: limeColors[500] }}>MK {formData.loanAmount.toLocaleString()}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Payback Period</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: isDarkMode ? 'white' : '#18181b' }}>{formData.paybackPeriodMonths} months</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a' }}>Repayment Method</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: isDarkMode ? 'white' : '#18181b' }}>{formData.repaymentMethod}</Typography>
                </Box>
              </Box>
            </Paper>

            {/* Declarations */}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.agreeToTerms}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, agreeToTerms: e.target.checked }));
                      if (errors.agreeToTerms) {
                        setErrors(prev => {
                          const newErrors = { ...prev };
                          delete newErrors.agreeToTerms;
                          return newErrors;
                        });
                      }
                    }}
                    sx={{
                      color: errors.agreeToTerms ? 'error.main' : limeColors[500],
                      '&.Mui-checked': {
                        color: limeColors[500],
                      },
                    }}
                  />
                }
                label={
                  <Typography sx={{ color: isDarkMode ? 'white' : '#18181b', fontWeight: 500 }}>
                    I agree to the terms and conditions
                  </Typography>
                }
              />
              {errors.agreeToTerms && (
                <Typography variant="caption" color="error">
                  {errors.agreeToTerms}
                </Typography>
              )}

              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.consentToCreditCheck}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, consentToCreditCheck: e.target.checked }));
                      if (errors.consentToCreditCheck) {
                        setErrors(prev => {
                          const newErrors = { ...prev };
                          delete newErrors.consentToCreditCheck;
                          return newErrors;
                        });
                      }
                    }}
                    sx={{
                      color: errors.consentToCreditCheck ? 'error.main' : limeColors[500],
                      '&.Mui-checked': {
                        color: limeColors[500],
                      },
                    }}
                  />
                }
                label={
                  <Typography sx={{ color: isDarkMode ? 'white' : '#18181b', fontWeight: 500 }}>
                    I consent to a credit check
                  </Typography>
                }
              />
              {errors.consentToCreditCheck && (
                <Typography variant="caption" color="error">
                  {errors.consentToCreditCheck}
                </Typography>
              )}

              {/* RBM Regulatory Info */}
              <Box sx={{ 
                mt: 4, 
                p: 2, 
                borderRadius: '16px', 
                bgcolor: isDarkMode ? 'rgba(132, 204, 22, 0.05)' : 'rgba(132, 204, 22, 0.03)',
                border: `1px dashed ${isDarkMode ? 'rgba(132, 204, 22, 0.3)' : 'rgba(132, 204, 22, 0.2)'}`,
                display: 'flex',
                alignItems: 'center',
                gap: 2
              }}>
                <ShieldCheck size={24} color={limeColors[500]} />
                <Typography variant="caption" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a', lineHeight: 1.4 }}>
                  VaultString is a licensed and regulated non-deposit-taking Microfinance Institution by the <Box component="span" sx={{ fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>Reserve Bank of Malawi (RBM)</Box>. Your data and application are protected by national financial regulations.
                </Typography>
              </Box>
            </Box>

            {submitSuccess && (
              <Alert severity="success" sx={{ mt: 3 }}>
                Application submitted successfully! Redirecting...
              </Alert>
            )}
          </Box>
        );

      default:
        return null;
    }
  };

  if (submitSuccess) {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Paper
          elevation={0}
          sx={{
            p: 6,
            textAlign: 'center',
            borderRadius: '24px',
            bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.02)' : 'white',
            border: `1.5px solid ${isDarkMode ? 'rgba(132, 204, 22, 0.2)' : 'rgba(132, 204, 22, 0.15)'}`
          }}
        >
          <CheckCircle size={64} color={limeColors[500]} style={{ marginBottom: 16 }} />
          <Typography variant="h4" sx={{ mb: 2, fontWeight: 700, color: isDarkMode ? 'white' : '#18181b' }}>
            Application Submitted!
          </Typography>
          <Typography variant="body1" sx={{ mb: 3, color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
            Your SME loan application has been successfully submitted. We'll review it and get back to you soon.
          </Typography>
          <Button
            variant="contained"
            onClick={() => router.push('/dashboard/applications')}
            sx={{
              bgcolor: limeColors[500],
              color: 'white',
              borderRadius: '12px',
              textTransform: 'none',
              fontWeight: 600,
              px: 4,
              py: 1.5,
              '&:hover': {
                bgcolor: limeColors[600],
              },
            }}
          >
            View My Applications
          </Button>
        </Paper>
      </Container>
    );
  }

  return (
    <>
      <Container maxWidth="lg" sx={{ py: 5 }}>
        <Typography
          variant="h3"
          sx={{
            mb: 2,
            fontWeight: 800,
            background: `linear-gradient(135deg, ${limeColors[500]} 0%, ${limeColors[600]} 100%)`,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}
        >
          SME Loan Application
        </Typography>
        <Typography variant="body1" sx={{ mb: 4, color: isDarkMode ? '#a1a1aa' : '#71717a' }}>
          Complete all steps to submit your application
        </Typography>

        {/* Progress Bar */}
        <Box sx={{ mb: 4 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="body2" sx={{ color: isDarkMode ? '#a1a1aa' : '#71717a', fontWeight: 600 }}>
              Step {activeStep + 1} of {steps.length}
            </Typography>
            <Typography variant="body2" sx={{ color: limeColors[500], fontWeight: 700 }}>
              {progress}% Complete
            </Typography>
          </Box>
          <Box sx={{
            height: 12,
            bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)',
            borderRadius: '100px',
            overflow: 'hidden',
            position: 'relative'
          }}>
            <Box
              sx={{
                height: '100%',
                bgcolor: `linear-gradient(90deg, ${limeColors[500]} 0%, ${limeColors[400]} 100%)`,
                background: `linear-gradient(90deg, ${limeColors[500]} 0%, ${limeColors[400]} 100%)`,
                width: `${progress}%`,
                transition: 'width 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
                borderRadius: '100px',
                boxShadow: `0 0 20px ${alpha(limeColors[500], 0.4)}`
              }}
            />
          </Box>
        </Box>

        {/* Custom Stepper */}
        <Box sx={{
          mb: 5,
          display: 'flex',
          justifyContent: 'space-between',
          position: 'relative',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: '24px',
            left: '5%',
            right: '5%',
            height: '2px',
            bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
            zIndex: 0
          }
        }}>
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isActive = index === activeStep;
            const isCompleted = index < activeStep;

            return (
              <Box
                key={step.label}
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  flex: 1,
                  position: 'relative',
                  zIndex: 1
                }}
              >
                <Box sx={{
                  width: '48px',
                  height: '48px',
                  borderRadius: '50%',
                  bgcolor: isCompleted ? limeColors[500] : isActive ? alpha(limeColors[500], 0.15) : (isDarkMode ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)'),
                  border: `2px solid ${isActive || isCompleted ? limeColors[500] : 'transparent'}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  mb: 1,
                  transition: 'all 0.3s ease',
                  boxShadow: isActive ? `0 0 20px ${alpha(limeColors[500], 0.4)}` : 'none'
                }}>
                  {isCompleted ? (
                    <CheckCircle size={24} color="white" />
                  ) : (
                    <Icon size={24} color={isActive ? limeColors[500] : (isDarkMode ? '#52525b' : '#a1a1aa')} />
                  )}
                </Box>
                <Typography
                  variant="caption"
                  sx={{
                    color: isActive || isCompleted ? (isDarkMode ? 'white' : '#18181b') : (isDarkMode ? '#71717a' : '#a1a1aa'),
                    fontWeight: isActive ? 600 : 400,
                    textAlign: 'center',
                    display: { xs: 'none', sm: 'block' }
                  }}
                >
                  {step.label}
                </Typography>
              </Box>
            );
          })}
        </Box>

        <Paper
          elevation={0}
          sx={{
            p: { xs: 3, sm: 4, md: 5 },
            mb: 4,
            borderRadius: '24px',
            bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.02)' : 'white',
            border: `1.5px solid ${isDarkMode ? 'rgba(132, 204, 22, 0.2)' : 'rgba(132, 204, 22, 0.15)'}`,
            minHeight: '500px'
          }}
        >
          {getStepContent(activeStep)}
        </Paper>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 2 }}>
          <Box sx={{ display: 'flex', gap: 2 }}>
            {activeStep > 0 && (
              <Button
                onClick={handleBack}
                startIcon={<ArrowLeft size={18} />}
                sx={{
                  color: isDarkMode ? 'white' : '#18181b',
                  borderColor: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                  borderRadius: '12px',
                  textTransform: 'none',
                  fontWeight: 600,
                  px: 3,
                  py: 1.5,
                  '&:hover': {
                    borderColor: limeColors[500],
                    bgcolor: alpha(limeColors[500], 0.05)
                  }
                }}
                variant="outlined"
              >
                Back
              </Button>
            )}
            <Button
              onClick={handleSaveDraft}
              startIcon={<Save size={18} />}
              variant="outlined"
              disabled={isLoading}
              sx={{
                color: limeColors[500],
                borderColor: limeColors[500],
                borderRadius: '12px',
                textTransform: 'none',
                fontWeight: 600,
                px: 3,
                py: 1.5,
                '&:hover': {
                  borderColor: limeColors[600],
                  bgcolor: alpha(limeColors[500], 0.1)
                },
                '&.Mui-disabled': {
                  borderColor: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                  color: isDarkMode ? 'rgba(255, 255, 255, 0.3)' : 'rgba(0, 0, 0, 0.3)'
                }
              }}
            >
              {isLoading ? <CircularProgress size={20} /> : 'Save Draft'}
            </Button>
          </Box>
          <Box>
            {activeStep === steps.length - 1 ? (
              <Button
                variant="contained"
                onClick={handleSubmit}
                disabled={isSubmitting}
                endIcon={isSubmitting ? <CircularProgress size={20} sx={{ color: 'white' }} /> : <CheckCircle size={18} />}
                sx={{
                  bgcolor: limeColors[500],
                  color: 'white',
                  borderRadius: '12px',
                  textTransform: 'none',
                  fontWeight: 700,
                  px: 4,
                  py: 1.5,
                  boxShadow: `0 4px 20px ${alpha(limeColors[500], 0.4)}`,
                  '&:hover': {
                    bgcolor: limeColors[600],
                    boxShadow: `0 6px 25px ${alpha(limeColors[500], 0.5)}`
                  },
                  '&.Mui-disabled': {
                    bgcolor: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                    color: isDarkMode ? 'rgba(255, 255, 255, 0.3)' : 'rgba(0, 0, 0, 0.3)'
                  }
                }}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Application'}
              </Button>
            ) : (
              <Button
                variant="contained"
                onClick={handleNext}
                endIcon={<ArrowRight size={18} />}
                sx={{
                  bgcolor: limeColors[500],
                  color: 'white',
                  borderRadius: '12px',
                  textTransform: 'none',
                  fontWeight: 700,
                  px: 4,
                  py: 1.5,
                  boxShadow: `0 4px 20px ${alpha(limeColors[500], 0.4)}`,
                  '&:hover': {
                    bgcolor: limeColors[600],
                    boxShadow: `0 6px 25px ${alpha(limeColors[500], 0.5)}`
                  }
                }}
              >
                Continue
              </Button>
            )}
          </Box>
        </Box>

        <Snackbar
          open={showSnackbar}
          autoHideDuration={3000}
          onClose={() => setShowSnackbar(false)}
          message={snackbarMessage}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
          ContentProps={{
            sx: {
              bgcolor: limeColors[500],
              color: 'white',
              borderRadius: '12px',
              fontWeight: 600,
              boxShadow: `0 4px 20px ${alpha(limeColors[500], 0.4)}`
            }
          }}
        />
      </Container>

      {preview && (
        <LocalFilePreviewModal
          file={preview.file}
          title={preview.title}
          onClose={() => setPreview(null)}
        />
      )}

      {isViewerOpen && (
        <DocumentViewer
          documents={viewerDocs}
          onClose={() => setIsViewerOpen(false)}
        />
      )}
    </>
  );
}